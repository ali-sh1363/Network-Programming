package Socket.Client.View;

import Socket.Client.Controller.ClientController;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Viewer implements Runnable {

    private ClientController clientController;
    private ViewerOutput vieweroutput;

    @Override
    public void run() {
        try {
            clientController = new ClientController();
            vieweroutput = new ViewerOutput();
            BufferedReader console = new BufferedReader(new InputStreamReader(System.in));
            clientController.connection(vieweroutput);
            String message;
            while(true){
                message= console.readLine();
                if(message.equals("n")){
                    clientController.disconnection();
                }else if(message.equals("y")) {
                    clientController.sendMessage(message);
                }
            }
        }catch (IOException e){
            System.out.println("Error from Client Viewer"+e.getMessage());
        }
    }
}
