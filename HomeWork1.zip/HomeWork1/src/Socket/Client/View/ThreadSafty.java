package Socket.Client.View;

public class ThreadSafty {
    synchronized void println(String consoleOutput) {
        System.out.println(consoleOutput);
    }
}
