package Socket.Client.View;

import Socket.Client.Network.ToView;

public class ViewerOutput implements ToView {
    ThreadSafty threadSafty = new ThreadSafty();


    @Override
    public  void messageForClient(String message) {
        threadSafty.println(message);

    }
}
