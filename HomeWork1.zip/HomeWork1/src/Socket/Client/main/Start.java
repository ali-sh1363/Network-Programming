package Socket.Client.main;

import Socket.Client.View.Viewer;

public class Start {

    public static void main (String[] args){
            Thread clientStartThread = new Thread(new Viewer());
            clientStartThread.start();

    }
}
