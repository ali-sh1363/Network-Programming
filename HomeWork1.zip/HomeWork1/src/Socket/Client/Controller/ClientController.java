package Socket.Client.Controller;

import Socket.Client.Network.ClientNetwork;
import Socket.Client.Network.ToView;

public class ClientController {

    private ClientNetwork clientNetwork = new ClientNetwork();

    public void connection(ToView toView){
        clientNetwork.ClientConnecting(toView);
//        CompletableFuture.runAsync(() -> {
//            clientNetwork.ClientConnecting(toView);
//        });
    }

    public  void disconnection(){
        clientNetwork.disconnect();
    }

    public void sendMessage(String message){
        clientNetwork.ClientSendMessage(message);
//        CompletableFuture.runAsync(() -> {
//            clientNetwork.ClientSendMessage(message);
//        });

    }
}
