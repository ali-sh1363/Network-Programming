package Socket.Client.Network;

import java.io.BufferedReader;
import java.io.IOException;

public class ClientIO implements Runnable {

    private BufferedReader inFromServer;
    private ToView toView;

    public ClientIO(BufferedReader inFromServer,ToView toView) {
        this.inFromServer = inFromServer;
        this.toView = toView;
    }
    @Override
    public void run() {
        try {
            String message;
            for (;;) {
                message = inFromServer.readLine();
               toView.messageForClient(message);
            }

        }catch (IOException e){
            System.out.println("Client IO "+e.getMessage());
        }
    }
}
