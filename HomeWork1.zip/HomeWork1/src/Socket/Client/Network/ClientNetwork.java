package Socket.Client.Network;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

import static Socket.Server.Model.HangMan.ANSI_BLUE;
import static Socket.Server.Model.HangMan.ANSI_RESET;

public class ClientNetwork {

    private PrintWriter outToServer;
    private BufferedReader inFromServer;
    private Socket client;

    public void ClientConnecting(ToView toView) {
        try {
            client = new Socket("localhost",5555);
            System.out.println("client is connecting");
            outToServer = new PrintWriter((client.getOutputStream()),true);   //true is for autoFlushing the buffer
            inFromServer = new BufferedReader(new InputStreamReader(client.getInputStream()));

            Thread clientThread = new Thread(new ClientIO(inFromServer,toView));
            clientThread.start();

        }catch (IOException e){
            System.out.println("client Network Error "+e.getMessage());
        }
    }
    public void disconnect(){
        try{

                System.out.println(ANSI_BLUE+"Thanks for Playing HangMan"+ANSI_RESET);
                outToServer.println("client left the game");
                client.close();

        }catch(IOException e){
            System.out.println("Disconnected form client Client Network "+e.getMessage());
        }
    }
    public void ClientSendMessage(String message){
        if (true){
            outToServer.println(message);
        }
    }
}
