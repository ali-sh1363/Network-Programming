package Socket.Client.Network;

public interface ToView {

    void messageForClient(String message);     //in order to show message on the client screen

}
