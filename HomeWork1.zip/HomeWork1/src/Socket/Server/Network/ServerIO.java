package Socket.Server.Network;

import Socket.Server.Controller.ServerController;

import java.io.*;
import java.net.Socket;

class ServerIO implements Runnable {

    private Socket server;

    private ServerController serverController;
    private PrintWriter outToClient;
    private BufferedReader inFromClient;
//    private int playerNumbers=0;

    public ServerIO(Socket server) {
        this.server=server;

    }

    @Override
    public void run() {
        try {
//             playerNumbers++;
             System.out.println("Player joined The Game");
//            System.out.println("The Number of Players: "+playerNumbers);
             outToClient = new PrintWriter(new OutputStreamWriter(server.getOutputStream()),true);   //true is for autoFlushing the buffer
             inFromClient = new BufferedReader(new InputStreamReader(server.getInputStream()));

            String userInput;
            serverController = new ServerController();
            serverController.Start(outToClient);

            while (true && (userInput=inFromClient.readLine())!=null ){

                if(userInput.equals("n")){
//                    playerNumbers--;
                    System.out.println("Player left The Game");
                    serverController.DisConnect(server);

                }else{
                    serverController.PlayerChecker(userInput,outToClient);
                }

            }
        }catch (IOException e){
            System.out.println("Server IO Error"+e.getMessage());
        }
    }
}
