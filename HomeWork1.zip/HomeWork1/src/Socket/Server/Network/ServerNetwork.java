package Socket.Server.Network;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ServerNetwork {
    private int playerNumbers=0;

    public void serverConnecting(){

        try{
            ServerSocket serverSocket = new ServerSocket(5555);
            ExecutorService executorService = Executors.newFixedThreadPool(5); // 5 clients can have access in a same time (ThreadPool)
            System.out.println("Server is Running!!!");

            while (true){                                                // for connecting multiple clients to the server(multiThreadServer)
                Socket server = serverSocket.accept();
                System.out.println("Client is connected!!!");
                playerNumbers++;
                System.out.println("The Number of PLayers: "+playerNumbers);
                Thread serverThread = new Thread(new ServerIO(server));
                executorService.execute(serverThread);
            }
        }catch (IOException e){
            System.out.println("server NetWork Error"+ e.getMessage());
        }
    }
}


