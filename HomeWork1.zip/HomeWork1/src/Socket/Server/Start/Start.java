package Socket.Server.Start;

import Socket.Server.Network.ServerNetwork;

public class Start {

    public static void main (String[] args){

        ServerNetwork serverNetwork = new ServerNetwork();
        serverNetwork.serverConnecting();


    }
}
