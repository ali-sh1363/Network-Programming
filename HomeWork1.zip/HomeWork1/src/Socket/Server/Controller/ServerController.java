package Socket.Server.Controller;

import Socket.Server.Model.HangMan;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;

public class ServerController  {
    private boolean isStarted = false;
    private boolean isMiddle = false;

    HangMan hangMan = new HangMan();

    public void Start(PrintWriter outToGame) {
        new HangMan().instructions(outToGame);
    }

    public void DisConnect(Socket server) throws IOException{
        server.close();
    }

//    public void PlayerChecker(String userInput, PrintWriter outToGame){
//
//             if (userInput.equals("y")){
//                 System.out.println("Player Starts The Game");
//                hangMan.game(outToGame,userInput);
//             }
//    }
        public void PlayerChecker(String userInput, PrintWriter outToGame) {
//
             if (userInput.equals("y")){
                 System.out.println("Player Starts The Game");
                hangMan.game(outToGame,userInput);
             }

        }

}
