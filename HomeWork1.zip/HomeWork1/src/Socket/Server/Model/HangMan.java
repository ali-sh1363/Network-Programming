package Socket.Server.Model;

import java.io.PrintWriter;

public class HangMan {

    public static final String ANSI_RESET = "\u001B[0m";
    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_GREEN = "\u001B[32m";
    public static final String ANSI_YELLOW = "\u001B[33m";
    public static final String ANSI_BLUE = "\u001B[34m";

    public final static void clearConsole() {
        try {
            final String os = System.getProperty("os.name");
            if (os.contains("Windows")) {
                Runtime.getRuntime().exec("cls");
            } else {
                Runtime.getRuntime().exec("clear");
            }
        } catch (final Exception e) {
        }
    }
    public void instructions(PrintWriter outToGame) {
        outToGame.println("=================================================================");
        outToGame.println(ANSI_GREEN + "                    Welcome to HANGMAN Game" + ANSI_RESET);
        outToGame.println(ANSI_GREEN + "      The Is a Game for Guessing The Name of Countries" + ANSI_RESET);
        outToGame.println("=================================================================");
        outToGame.println("Are You Ready to Start ? (Y/N)");
    }
    public void start_game(PrintWriter outToGame) {
             outToGame.println("Game Starts in :");
            for (int i = 3; i >= 1; i--) {
                outToGame.println(i + " seconds");
                try {
                    Thread.sleep(1000);
                } catch (Exception e) {
                    outToGame.println(e);
                }
            }
    }
    public void game(PrintWriter outToGame,String choice) {
        String word_list[] = {"", "INDIA", "BRAZIL", "SPAIN", "IRAN", "RUSSIA", "JAPAN", "GERMANY", "ITALY", "CHINA", "INDONESIA", "PORTUGAL", "SWEDEN", "SWITZERLAND", "SINGAPORE", "CANADA", "MEXICO", "ARGENTINA", "SCOTLAND", "GREENLAND", "FINLAND"};
        String choice_cont = "";
        do {
            start_game(outToGame);
            int word_index = (int) (Math.random() * (word_list.length - 1) + 1);
            String word = word_list[word_index];
            int len = word.length();
            String dash[] = new String[len];
            for (int i = 0; i < len; i++)
                dash[i] = "_";
            outToGame.println("Your Word to Guess is:");
            for (int i = 0; i < len; i++)
                outToGame.print(dash[i] + "  ");
            int flag = 0, dup_flag = 0;
            int wrong_attempts = 0;
            while (wrong_attempts <= 10) {
              //  outToGame.println("hello");
                //String char_input = scanner.next();
                String char_input = choice ;
                outToGame.println();
                int count_index = 0;
                for (int j = 0; j < len; j++) {
                    if (char_input.equalsIgnoreCase(Character.toString(word.charAt(j)))) {
                        dash[j] = Character.toString(word.charAt(j));
                        count_index++;
                    }
                }
                if (count_index == 0)
                    wrong_attempts++;
                for (int j = 0; j < len; j++)
                    outToGame.print(dash[j] + "  ");
                int f = 0;
                for (int k = 0; k < len; k++) {
                    if (dash[k].equals("_"))
                        f++;
                }
                if (f == 0) {
                    dup_flag = 1;
                    break;
                }
            }
            for (int i = 0; i < len; i++) {
                if (dash[i].equals("_")) {
                    flag = 1;
                    break;
                }
            }
            outToGame.println();
            if (flag == 1 || dup_flag == 0)
                outToGame.println("YOU LOSE");
            else
                outToGame.println("YOU WIN");
            outToGame.println("Do You Want to Continue (Y/N) ?");
          //  choice_cont = scanner.next();
            if (choice_cont.equalsIgnoreCase("N")) {
                outToGame.println(ANSI_RED + "Thank You for Using HANGMAN." + ANSI_RESET);
            }
        } while (choice_cont.equals("Y") || choice_cont.equals("y"));
    }

}
