
package sockets.server.network;

import sockets.server.controller.ServerController;

import java.io.*;
import java.net.Socket;


public class ServerIO implements Runnable{
    private final Socket playerSocket;
    private PrintWriter outToPlayer;
    private BufferedReader inFromPlayer;
    private final boolean autoFlush = true;
    private boolean  connected = false;
    private ServerController serverController;
    private static int numberOfPlayers = 0;
    
    
    public ServerIO(Socket playerSocket){
        this.playerSocket = playerSocket;
        this.connected = true;
    }
    @Override
    public void run(){
        try{
            numberOfPlayers++;
            System.out.println("Player joined The Game");
            System.out.println("Number of players in the game: " + numberOfPlayers);
            outToPlayer = new PrintWriter(new OutputStreamWriter(playerSocket.getOutputStream()),autoFlush);
            inFromPlayer = new BufferedReader(new InputStreamReader(playerSocket.getInputStream()));
                       
            String userInput;
            serverController = new ServerController();
            serverController.intro(outToPlayer);
           
            while(connected && ((userInput = inFromPlayer.readLine())!=null)){
                
                if(userInput.startsWith("exit") && userInput.length()==4){
                    System.out.println("Client Left The Game");
                    numberOfPlayers--;
                    serverController.disconnect(playerSocket);
                    connected = false;
                }
                else{
                    serverController.checkUserInput(userInput,outToPlayer);
                }
            }
        } catch(IOException e){
            System.out.println("ServerIO !!! "+e.getMessage());
        }
    }
     
}
