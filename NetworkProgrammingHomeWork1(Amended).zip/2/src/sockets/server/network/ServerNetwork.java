
package sockets.server.network;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class ServerNetwork {

    private ServerSocket serverSocket;
    private Socket playerSocket;
    private ExecutorService executor;

    public void serve(){
        try{
            serverSocket = new ServerSocket(6000);              // we can select a port between 1024 - 65535
            playerSocket = new Socket();
            executor = Executors.newFixedThreadPool(5);     // 5 clients can have access in a same time (ThreadPool)
            System.out.println("Server is Running !!!");
            while(true){                                             // for connecting multiple clients to the server(multiThreadServer)
                playerSocket = serverSocket.accept();
                Thread playerThread = new Thread(new ServerIO(playerSocket));
                executor.execute(playerThread);
            }
        } catch (IOException e){
            System.out.println("ServerNetwork !!!" +e.getMessage());
        } finally{
            if (executor != null){
                executor.shutdown();
            }
        }
    }
    
}
    