

package sockets.server.model;

import java.io.PrintWriter;

import static sockets.server.model.ThreadColor.*;


public class Hangman {
    
    private int score = 0;
    private int attemptNumber;
    private String chosenWord;
    private static final char SHOW_SCREEN = '_';
    private static final char SPACE = ' ';
    private String outputInScreen;
    public boolean gameWinLoseState = false;
    
    
    public Hangman(){
        this.chosenWord = " ";
        this.attemptNumber = 0;
    }

    public Hangman(String chosenWord, int attemptNo){
        this.chosenWord = chosenWord;
        this.attemptNumber = attemptNo;
    }
    
    private void IncreaseScore(){
        score++;
    }
    
    private void DecreaseScore(){
        score--;
    }
    
    
    public StringBuilder hangmanCheckChar(char c, StringBuilder screenWord, PrintWriter outToPlayer){
       
        boolean changed = false;
        boolean win = false;
        for(int i=0; i < chosenWord.length(); i++){
           if(c==chosenWord.charAt(i)){
               if(screenWord.charAt(i)==SHOW_SCREEN){
                   screenWord.setCharAt(i, c);
                   changed = true;
               }
               else{
                   return screenWord; 
               }
           }
        }
        
        if(changed == true){
            if(hangmanWin(screenWord)){
                IncreaseScore();
                outputInScreen = chosenWord.substring(0, 1).toUpperCase() + chosenWord.substring(1);
                outToPlayer.println("\nCongrats! The correct word was: " + outputInScreen + "\nYour Score: " + score + "\n");
                screenWord = selectNextWord(screenWord);
            }
            else{
                outToPlayer.println("Bravo!\n");
            }
        }
        else{
            outToPlayer.println("Wrong!\n");
            attemptNumber--;
            if (attemptNumber == 0){
                DecreaseScore();
                gameWinLoseState = true;
                outputInScreen = chosenWord.substring(0, 1).toUpperCase() + chosenWord.substring(1);
                outToPlayer.println("\nYou Lost! The correct word was: " + outputInScreen + "\nYour Score: " + score + "\n");
                screenWord = selectNextWord(screenWord);
            }
        }
        return screenWord;
    }

    public StringBuilder hangmanCheckWord(String userInput, StringBuilder screenWord, PrintWriter outToPlayer){
        
        if (userInput.equals(chosenWord.trim())){
            IncreaseScore();
            gameWinLoseState = true;
            outputInScreen = chosenWord.substring(0, 1).toUpperCase() + chosenWord.substring(1);
            outToPlayer.println("\nCongrats! The correct word was: " + outputInScreen + "\nYour Score: " + score + "\n");
            screenWord = selectNextWord(screenWord);
        }
            
        else{
            outToPlayer.println("Wrong!\n");
            attemptNumber--;
            if (attemptNumber == 0){
                DecreaseScore();
                gameWinLoseState = true;
                outputInScreen = chosenWord.substring(0, 1).toUpperCase() + chosenWord.substring(1);
                outToPlayer.println("\nYou Lost! The correct word was: " + outputInScreen + "\nYour Score: " + score + "\n");
                screenWord = selectNextWord(screenWord);
            }
        }
 
        return screenWord;
    }
    
    private boolean hangmanWin(StringBuilder screenWord){
        int found = screenWord.toString().indexOf(SHOW_SCREEN);
        if(found == -1){
            gameWinLoseState = true;
            return true;
        }
        return false;
    }
    
    private StringBuilder selectNextWord(StringBuilder screenWord){
        RandomWord newWord = new RandomWord();
        chosenWord = newWord.getTheWord();
        attemptNumber = chosenWord.length();
        screenWord = new StringBuilder(chosenWord);
        for (int i = 0; i < screenWord.length(); i++){
            screenWord.setCharAt(i, SHOW_SCREEN);
        }
        return screenWord;
        
    }
    
    
    public void showState(StringBuilder wordScreen, PrintWriter outToPlayer){                                          
        StringBuilder outputBuilder = new StringBuilder(wordScreen.toString() + wordScreen.toString());
        
        //outputInScreen;
        for (int i = 0; i < wordScreen.length(); i++){
                outputBuilder.setCharAt(2*i, wordScreen.charAt(i));
                outputBuilder.setCharAt(2*i+1, SPACE);
            }
        outputInScreen = outputBuilder.toString();
        outputInScreen = outputInScreen.substring(0,1).toUpperCase() + outputInScreen.substring(1);
        outToPlayer.println("Word:\t" + outputInScreen + "\t\tAttemp: " + attemptNumber + "\t\tScore: " + score + " \n");
    }
    
    
    public void showIntro(PrintWriter outToPlayer){
        outToPlayer.println("=================================================================");
        outToPlayer.println(ANSI_PURPLE + "                    Welcome to HANGMAN Game" + ANSI_RESET);
        outToPlayer.println(ANSI_PURPLE + "      The Is a Game for Guessing The Name of Countries" + ANSI_RESET);
        outToPlayer.println("=================================================================");
        outToPlayer.println(ANSI_YELLOW+"If You Want to Start the Game please Type 'START':"+ANSI_RESET);
        outToPlayer.println(ANSI_YELLOW+"If You Want to EXIT the Game please Type 'EXIT':"+ANSI_RESET);

    }

    public void start_game (PrintWriter outToPlayer) {
        outToPlayer.println("Game Starts in :");
        for (int i = 3; i >= 1; i--) {
            outToPlayer.println(i + " seconds");
            try {
                Thread.sleep(1000);
            } catch (Exception e) {
                outToPlayer.println(e);
            }
        }

    }

}
