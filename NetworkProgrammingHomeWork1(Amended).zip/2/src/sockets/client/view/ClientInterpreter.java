/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sockets.client.view;

import sockets.client.controller.ClientController;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ClientInterpreter implements Runnable{
    
//    private final int serverPort;
    private ClientController clientController;
    private ConsoleOutput screenHandler;
    private BufferedReader console;
    private static boolean ThreadStarted = false;
    

    @Override
    public void run() {

        ThreadStarted = true;
        clientController = new ClientController();
        console = new BufferedReader(new InputStreamReader(System.in));
        String command;
        screenHandler = new ConsoleOutput();
        clientController.connect(screenHandler);

        while (ThreadStarted) {
            try {

                command = console.readLine().toLowerCase();
                if (command.startsWith("exit") && command.length() == 4) {
                    clientController.exit();
                    ThreadStarted = false;
                } else {
                    clientController.sendMessage(command);
                }

            } catch (IOException e) {
                System.out.println("ClientInterPerter !!! " + e.getMessage());
            }
        }
    }
}
