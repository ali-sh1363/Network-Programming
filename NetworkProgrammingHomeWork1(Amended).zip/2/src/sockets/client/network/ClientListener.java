/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sockets.client.network;

import java.io.BufferedReader;
import java.io.IOException;

import static sockets.server.model.ThreadColor.ANSI_BLUE;
import static sockets.server.model.ThreadColor.ANSI_RESET;

public class ClientListener implements Runnable {
        private final OutputHandler outputHandler;
        private final BufferedReader fromServer;
        
        public ClientListener(OutputHandler outputHandler,BufferedReader fromServer) {
            this.outputHandler = outputHandler;
             this.fromServer = fromServer;
        }
        @Override
        public void run(){
            try {
                String message;
                for (;;) {
                    message = fromServer.readLine();
                    outputHandler.messageOnScreen(message);
                }
            } catch (IOException e) {
                System.out.println(ANSI_BLUE+"Thanks For Playing HANGMAN"+ANSI_RESET);
            } catch (NullPointerException e){
                System.out.println("ClientListener !!! "+e.getMessage());
            }
        }

}