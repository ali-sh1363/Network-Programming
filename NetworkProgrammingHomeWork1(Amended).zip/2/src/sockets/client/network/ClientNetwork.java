/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sockets.client.network;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class ClientNetwork {
    private Socket clientSocket; 
    private PrintWriter toServer;
    private BufferedReader fromServer;
    private Thread listenerThread;
    private boolean connected = true;

    public void connect(OutputHandler screenHandler){
        try{
            clientSocket = new Socket("localhost",6000);
            System.out.println("client is connecting");
            toServer = new PrintWriter(clientSocket.getOutputStream(), true );   //autoFlash
            fromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            listenerThread = new Thread(new ClientListener(screenHandler, fromServer));
            listenerThread.start();
                        
        } catch (IOException e){
            System.out.println("ClientNetwork connect !!! "+e.getMessage());
        }
    }
    public void disconnect(){
        try{
            if (connected){
                toServer.println("exit");
                clientSocket.close();
                connected = false;
            }

        } catch(IOException e){
            System.out.println("ClientNetwork disconnect !!! "+e.getMessage());
        }
    }
    
    public void sendMessage(String charGuess){
        if(connected){
            toServer.println(charGuess);
        }
        else{
            System.out.println("Start The Game");
        }
    }
    
    
  
}
