/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sockets.client.controller;

import sockets.client.network.ClientNetwork;
import sockets.client.network.OutputHandler;

public class ClientController {
    
    private final ClientNetwork clientSocket = new ClientNetwork();
        
    public void connect(OutputHandler screenHandler) {
        clientSocket.connect(screenHandler);
    }
    public void exit() {
        clientSocket.disconnect();
    }

    public void sendMessage(String command)  {
        clientSocket.sendMessage(command);
    }
}
